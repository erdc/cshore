%function [x_m] = ft2m(x_ft)
function [x_m] = ft2m(x_ft)
x_m = x_ft*.3048;
