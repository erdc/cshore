%function [x_ft] = m2ft(x_m)
function [x_ft] = m2ft(x_m)
x_ft = x_m./.3048;
